================================================This script is connecting to MySQL server, executes mysqldump and saves dumpfile to specified directory.
config file path is <python3 lib directory>/site|dist-packages/daily_backup/config/backup.json
run following command to executes this scripts!(must be privileged user)
python3 <python3 lib directory>/dist-packages/daily_backup/local_backup.py
Home-page: UNKNOWN
Author: Takeki Shikano
Author-email: shikano.takeki@nexon.co.jp
License: MIT
Description-Content-Type: UNKNOWN
Description: Sample Module Repository
        ========================
        
        This simple project is an example repo for Python projects.
        
        `Learn more <http://www.kennethreitz.org/essays/repository-structure-and-python>`_.
        
        ---------------
        
        If you want to learn more about ``setup.py`` files, check out `this repository <https://github.com/kennethreitz/setup.py>`_.
        
        笨ｨ魂笨ｨ
        
Platform: UNKNOWN
